<?php

// Admin page setup
function multi_viewer_add_admin_menu() {
    add_menu_page(
        '3D Multi-Viewer', 
        '3D Multi-Viewer', 
        'manage_options', 
        '3d-multi-viewer', 
        'multi_viewer_admin_page', 
        'dashicons-visibility', 
        20
    );
}
add_action('admin_menu', 'multi_viewer_add_admin_menu');

function multi_viewer_admin_page() {
    ?>
<div class="wrap">
  <h1>3D Multi-Viewer Plugin</h1>
  <p>Embed and manage Spline and Sketchfab models directly on your site using shortcodes.</p>

  <h2>Instructions</h2>
  <ul>
    <li>To embed a Spline model, use: <code>[multiviewer type="spline" src="YOUR_MODEL_URL"]</code></li>
    <li>To embed a Sketchfab model, use: <code>[multiviewer type="sketchfab" src="YOUR_MODEL_URL"]</code></li>
  </ul>
</div>
<?php
}
?>