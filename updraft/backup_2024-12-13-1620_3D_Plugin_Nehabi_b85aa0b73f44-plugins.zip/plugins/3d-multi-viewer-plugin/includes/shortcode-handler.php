<?php

// Shortcode handler
function multi_viewer_shortcode($atts) {
    $atts = shortcode_atts(
        array(
            'type' => 'spline',  // Type: 'spline' or 'sketchfab'
            'src' => '',         // URL of the model or embed iframe source
            'width' => '100%',   // Viewer width
            'height' => '500px'  // Viewer height
        ),
        $atts
    );

    // Error handling for missing model URL
    if (empty($atts['src'])) {
        return '<p>Error: No model URL provided.</p>';
    }

    // Handle each model type
    switch ($atts['type']) {
        case 'spline':
            return '<iframe src="' . esc_url($atts['src']) . '" frameborder="0" style="width:' . esc_attr($atts['width']) . '; height:' . esc_attr($atts['height']) . ';"></iframe>';

        case 'sketchfab':
            return '<iframe src="' . esc_url($atts['src']) . '" frameborder="0" allow="autoplay; fullscreen" style="width:' . esc_attr($atts['width']) . '; height:' . esc_attr($atts['height']) . ';"></iframe>';

        default:
            return '<p>Error: Unsupported type "' . esc_html($atts['type']) . '". Supported types are "spline" and "sketchfab".</p>';
    }
}
add_shortcode('multiviewer', 'multi_viewer_shortcode');