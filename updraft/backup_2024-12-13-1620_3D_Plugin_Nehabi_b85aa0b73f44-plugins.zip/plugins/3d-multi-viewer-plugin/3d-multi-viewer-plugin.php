<?php
/**
 * Plugin Name: 3D Multi-Viewer Plugin
 * Description: A WordPress plugin to embed Spline and Sketchfab models.
 * Version: 1.1
 * Author: Your Name
 */

// Enqueue scripts and styles
function multi_viewer_enqueue_assets() {
    // Enqueue the plugin stylesheet
    wp_enqueue_style('multi-viewer-style', plugin_dir_url(__FILE__) . 'css/style.css');
}
add_action('wp_enqueue_scripts', 'multi_viewer_enqueue_assets');
// Shortcode handler
function multi_viewer_shortcode($atts) {
    $atts = shortcode_atts(
        array(
            'type' => 'spline',          // Type: 'spline' or 'sketchfab'
            'src' => '',                 // URL of the model or embed iframe source
            'width' => '100%',           // Viewer width
            'height' => '500px',         // Viewer height
            'background' => 'transparent', // Background color (optional)
            'border' => 'none',          // Border style (optional)
            'shadow' => 'none',          // Shadow effect (optional)
            'padding' => '0',            // Padding around the viewer (optional)
            'scale' => '100%',           // Scale percentage (optional)
            'zoom' => '',                // Zoom level (optional)
            'rotation' => '',            // Rotation angle (optional)
            'lighting' => '',            // Lighting effect (optional)
        ),
        $atts
    );

    // Error handling for missing model URL
    if (empty($atts['src'])) {
        return '<p>Error: No model URL provided.</p>';
    }

    // Prepare URL modifications
    $url_params = [];
    
    // Add background or any other relevant parameters to the URL based on model type
    if ($atts['type'] === 'spline') {
        if ($atts['background']) $url_params['bg_color'] = urlencode($atts['background']);
        if ($atts['scale']) $url_params['scale'] = urlencode($atts['scale']);
        if ($atts['zoom']) $url_params['zoom'] = urlencode($atts['zoom']);
        if ($atts['rotation']) $url_params['rotation'] = urlencode($atts['rotation']);
        if ($atts['lighting']) $url_params['lighting'] = urlencode($atts['lighting']);
    } elseif ($atts['type'] === 'sketchfab') {
        if ($atts['background']) $url_params['background_color'] = urlencode($atts['background']);
        if ($atts['scale']) $url_params['scale'] = urlencode($atts['scale']);
        if ($atts['zoom']) $url_params['zoom'] = urlencode($atts['zoom']);
        if ($atts['rotation']) $url_params['rotation'] = urlencode($atts['rotation']);
        if ($atts['lighting']) $url_params['lighting'] = urlencode($atts['lighting']);
    }

    // Build the final URL with parameters
    $url_with_params = esc_url($atts['src']);
    if (!empty($url_params)) {
        $url_with_params .= '?' . http_build_query($url_params);
    }

    // Prepare custom styles for iframe
    $style = 'width:' . esc_attr($atts['width']) . ';';
    $style .= 'height:' . esc_attr($atts['height']) . ';';
    $style .= 'background:' . esc_attr($atts['background']) . ';'; // This is for iframe background
    $style .= 'border:' . esc_attr($atts['border']) . ';';
    $style .= 'box-shadow:' . esc_attr($atts['shadow']) . ';';
    $style .= 'padding:' . esc_attr($atts['padding']) . ';';

    // Handle each model type
    switch ($atts['type']) {
        case 'spline':
            return '<iframe src="' . $url_with_params . '" frameborder="0" style="' . $style . '"></iframe>';

        case 'sketchfab':
            return '<iframe src="' . $url_with_params . '" frameborder="0" allow="autoplay; fullscreen" style="' . $style . '"></iframe>';

        default:
            return '<p>Error: Unsupported type "' . esc_html($atts['type']) . '". Supported types are "spline" and "sketchfab".</p>';
    }
}
add_shortcode('multiviewer', 'multi_viewer_shortcode');

function multi_viewer_admin_page() {
    ?>
<div class="wrap">
  <h1>3D Multi-Viewer Plugin</h1>
  <p>Embed and manage Spline and Sketchfab models directly on your site using shortcodes.</p>

  <h2>Instructions</h2>
  <ul>
    <li>To embed a Spline model, use: <code>[multiviewer type="spline" src="YOUR_MODEL_URL"]</code></li>
    <li>To embed a Sketchfab model, use: <code>[multiviewer type="sketchfab" src="YOUR_MODEL_URL"]</code></li>
  </ul>
</div>
<?php
}
?>